import {describe,it,expect} from 'vitest';
import {PairingController} from '../dist/controller.js';
import {fixture} from '../harness/synthetic.js';
async function paired(f=fixture()) {
 const rx=new PairingController('receiver',f.adapters),tx=new PairingController('sender',f.adapters);
 await rx.startReceiver();await tx.load(rx.pairingDocument()!);await tx.approveDestination();
 await rx.check();await tx.check();await rx.check();
 return {rx,tx,f};
}
async function confirmed(f=fixture()) {
 const p=await paired(f);
 await p.tx.confirm(p.rx.getSnapshot().comparison!);await p.rx.confirm(p.tx.getSnapshot().comparison!);return p;
}
describe('SDK presentation controller',()=>{
 it('admits, compares, commits and waits for durable acknowledgement',async()=>{
  const {rx,tx,f}=await confirmed();
  expect(f.calls.indexOf('admit')).toBeLessThan(f.calls.indexOf('create'));
  await tx.transfer();expect(tx.getSnapshot().stage).toBe('waiting');
  await tx.check();expect(tx.getSnapshot().problem).toBe('pending');
  await rx.transfer();expect(rx.getSnapshot().stage).toBe('complete');
  expect([...f.saved!.bytes]).toEqual([11,22,33,44]);
  await tx.check();expect(tx.getSnapshot().stage).toBe('complete');
  expect(rx.pairingDocument()).toBeUndefined();
 });
 it('reconciles a lost completion response after expiry without importing twice',async()=>{
  const {rx,tx,f}=await confirmed();await tx.transfer();f.failures.add('complete');await rx.transfer();
  expect(rx.getSnapshot().stage).toBe('ready');expect(rx.getSnapshot().problem).toBe('transport');
  f.advance(120001);rx.expire();expect(rx.getSnapshot().stage).toBe('expired');
  f.failures.delete('complete');await rx.reconcile();await tx.check();
  expect(rx.getSnapshot().stage).toBe('complete');expect(tx.getSnapshot().stage).toBe('complete');
  expect(f.calls.filter(c=>c==='storage')).toHaveLength(1);
 });
 it.each(['protection','unlock','identity','authority','storage','send','receive','admit','join','offer','create','completed','lookup'])(
  'sanitizes %s refusal and never reports completion',async failure=>{
   const f=fixture();const p=await paired(f);
   if(['protection','unlock','identity','authority','admit'].includes(failure)) {
    p.rx.dispose();p.tx.dispose();f.failures.add(failure);
    const rx=new PairingController('receiver',f.adapters);await rx.startReceiver();
    if(failure==='protection'){expect(rx.getSnapshot().problem).toBe('protection');return;}
    const tx=new PairingController('sender',f.adapters);await tx.load(rx.pairingDocument()!);await tx.approveDestination();
    expect(tx.getSnapshot().problem).toBeDefined();expect(JSON.stringify(tx.getSnapshot())).not.toContain('PRIVATE-SENTINEL');
   } else if(['create','join','offer'].includes(failure)) {
    f.failures.add(failure);const rx=new PairingController('receiver',f.adapters);await rx.startReceiver();
    const tx=new PairingController('sender',f.adapters);await tx.load(rx.pairingDocument()!);await tx.approveDestination();
    await rx.check();await tx.check();expect([rx.getSnapshot().problem,tx.getSnapshot().problem]).toContain('transport');
   } else {
    await p.rx.confirm(p.tx.getSnapshot().comparison!);await p.tx.confirm(p.rx.getSnapshot().comparison!);
    f.failures.add(failure);await p.tx.transfer();await p.rx.transfer();await p.tx.check();
    const failing=failure==='send'||failure==='completed'?p.tx:p.rx;
    expect(failing.getSnapshot().stage).not.toBe('complete');expect(failing.getSnapshot().problem).toBeDefined();
    expect(JSON.stringify(failing.getSnapshot())).not.toContain('PRIVATE-SENTINEL');
   }
  });
 it('refuses wrong comparison without sending private material',async()=>{
  const {tx,f}=await paired();await tx.confirm('wrong');await tx.transfer();
  expect(tx.getSnapshot().stage).not.toBe('ready');expect(f.calls).not.toContain('send');
 });
 it('retries an uncertain upload without reporting success early',async()=>{
  const {tx,rx,f}=await confirmed();f.failures.add('send');await tx.transfer();expect(tx.getSnapshot().stage).toBe('waiting');
  f.failures.delete('send');await tx.retryUpload();await rx.transfer();await tx.check();expect(tx.getSnapshot().stage).toBe('complete');
 });
 it('cancels pending unlock and zeroes bytes returned late',async()=>{
  const f=fixture();let resolve!:(v:{identity:any;keyring:Uint8Array})=>void;
  const unlocked=await f.adapters.unlock(new AbortController().signal);
  f.adapters.unlock=()=>new Promise(r=>resolve=r);
  const rx=new PairingController('receiver',f.adapters);await rx.startReceiver();
  const tx=new PairingController('sender',f.adapters);await tx.load(rx.pairingDocument()!);
  const running=tx.approveDestination();await tx.cancel();resolve(unlocked);await running;
  expect([...unlocked.keyring]).toEqual([0,0,0,0]);expect(tx.getSnapshot().stage).toBe('cancelled');expect(f.calls).not.toContain('admit');
 });
 it('refuses oversized, malformed and foreign-scope documents before unlock',async()=>{
  const f=fixture(),tx=new PairingController('sender',f.adapters);
  for(const value of ['x'.repeat(8193),'{}','{"priv":"secret"}']){await tx.load(value);expect(tx.getSnapshot().problem).toBe('invalid');}
  const rx=new PairingController('receiver',{...f.adapters,scope:{...f.adapters.scope,tenant:'other'}});await rx.startReceiver();
  await tx.load(rx.pairingDocument()!);expect(tx.getSnapshot().problem).toBe('scope');expect(f.calls).not.toContain('unlock');
 });
 it('expires before upload and clears bootstrap data',async()=>{
  const {rx,tx,f}=await paired();f.advance(120001);rx.expire();tx.expire();
  expect(rx.getSnapshot().stage).toBe('expired');expect(tx.getSnapshot().stage).toBe('expired');expect(rx.pairingDocument()).toBeUndefined();
 });
});
it('refuses missing cryptography before preparing or exporting identity',async()=>{
 const f=fixture(),prior=globalThis.crypto;
 Object.defineProperty(globalThis,'crypto',{value:undefined,configurable:true});
 try {
  const rx=new PairingController('receiver',f.adapters);await rx.startReceiver();
  expect(rx.getSnapshot().problem).toBe('crypto');expect(f.calls).toEqual([]);
 } finally {Object.defineProperty(globalThis,'crypto',{value:prior,configurable:true});}
});
it('cancels while protection is preparing without publishing a request',async()=>{
 const f=fixture();let resolve!:()=>void;
 f.adapters.prepareProtection=()=>new Promise(r=>resolve=r);
 const rx=new PairingController('receiver',f.adapters),running=rx.startReceiver();
 await rx.cancel();resolve();await running;
 expect(rx.getSnapshot().stage).toBe('cancelled');expect(rx.pairingDocument()).toBeUndefined();
});
