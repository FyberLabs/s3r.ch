// @vitest-environment jsdom
import {it,expect,vi,afterEach} from 'vitest';
import {scanPairingQr} from '../dist/qr.js';
afterEach(()=>vi.unstubAllGlobals());
function camera() {
 const stop=vi.fn(),video=document.createElement('video');video.srcObject=null;
 video.play=vi.fn(async()=>{});
 const stream={getTracks:()=>[{stop}]} as unknown as MediaStream;
 return {stop,video,stream};
}
it('stops tracks and clears preview after reading a QR',async()=>{
 const c=camera();
 vi.stubGlobal('navigator',{mediaDevices:{getUserMedia:vi.fn(async()=>c.stream)}});
 vi.stubGlobal('BarcodeDetector',class {async detect(){return [{rawValue:'bounded-document'}];}});
 expect(await scanPairingQr(c.video,new AbortController().signal)).toBe('bounded-document');
 expect(c.stop).toHaveBeenCalledOnce();expect(c.video.srcObject).toBeNull();
});
it('stops late camera access after cancellation without scanning',async()=>{
 const c=camera();let resolve!:(stream:MediaStream)=>void;const detect=vi.fn();
 vi.stubGlobal('navigator',{mediaDevices:{getUserMedia:()=>new Promise(r=>resolve=r)}});
 vi.stubGlobal('BarcodeDetector',class {detect=detect;});
 const abort=new AbortController(),result=scanPairingQr(c.video,abort.signal);
 abort.abort();resolve(c.stream);
 await expect(result).rejects.toMatchObject({code:'camera'});
 expect(c.stop).toHaveBeenCalledOnce();expect(detect).not.toHaveBeenCalled();expect(c.video.srcObject).toBeNull();
});
it('stops tracks on detector refusal and rejects oversized documents',async()=>{
 for(const value of ['oversized','refused']){
  const c=camera();
  vi.stubGlobal('navigator',{mediaDevices:{getUserMedia:async()=>c.stream}});
  vi.stubGlobal('BarcodeDetector',class {async detect(){if(value==='refused')throw Error('private camera detail');return [{rawValue:'x'.repeat(8193)}];}});
  await expect(scanPairingQr(c.video,new AbortController().signal)).rejects.toMatchObject({code:value==='refused'?'camera':'invalid'});
  expect(c.stop).toHaveBeenCalledOnce();
 }
});

it('does not detach a replacement preview when cancelled camera access resolves late',async()=>{
 const old=camera(),next=camera();const video=old.video;
 let grantOld!:(stream:MediaStream)=>void,detectNext!:(rows:{rawValue:string}[])=>void;
 const getUserMedia=vi.fn().mockImplementationOnce(()=>new Promise(r=>grantOld=r)).mockResolvedValueOnce(next.stream);
 vi.stubGlobal('navigator',{mediaDevices:{getUserMedia}});
 vi.stubGlobal('BarcodeDetector',class {detect(){return new Promise(r=>detectNext=r);}});
 const oldAbort=new AbortController(),oldScan=scanPairingQr(video,oldAbort.signal);
 oldAbort.abort();const nextScan=scanPairingQr(video,new AbortController().signal);
 await vi.waitFor(()=>expect(video.srcObject).toBe(next.stream));
 grantOld(old.stream);await expect(oldScan).rejects.toMatchObject({code:'camera'});
 expect(old.stop).toHaveBeenCalledOnce();expect(next.stop).not.toHaveBeenCalled();expect(video.srcObject).toBe(next.stream);
 detectNext([{rawValue:'new-document'}]);expect(await nextScan).toBe('new-document');
 expect(next.stop).toHaveBeenCalledOnce();expect(video.srcObject).toBeNull();
});
