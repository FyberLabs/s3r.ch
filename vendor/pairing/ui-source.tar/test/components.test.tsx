// @vitest-environment jsdom
import React from 'react';
import {it,expect,vi,afterEach} from 'vitest';
import {render,screen,fireEvent,waitFor,cleanup} from '@testing-library/react';
import {ReceiverFlow,SenderFlow} from '../dist/index.js';
import {PairingProblem} from '../dist/controller.js';
import {fixture} from '../harness/synthetic.js';
vi.mock('../dist/qr.js',()=>({drawPairingQr:vi.fn(async()=>{}),scanPairingQr:vi.fn(async()=>{throw new PairingProblem('camera');})}));
afterEach(cleanup);
it('shows accessible protection refusal without unsafe downgrade',async()=>{
 const f=fixture();f.failures.add('protection');render(<ReceiverFlow adapters={f.adapters}/>);
 fireEvent.click(screen.getByText('Create pairing request'));
 await waitFor(()=>expect(screen.getByRole('alert').textContent).toContain('Secure local protection'));
 expect(screen.queryByText('Save pairing file')).toBeNull();expect(document.body.textContent).not.toContain('PRIVATE-SENTINEL');
});
it('offers file fallback after camera denial and stops at destination confirmation',async()=>{
 const f=fixture();render(<SenderFlow adapters={f.adapters}/>);
 fireEvent.click(screen.getByText('Scan receiving device QR'));
 await waitFor(()=>expect(screen.getByRole('alert').textContent).toContain('pairing file'));
 expect(screen.getByLabelText(/Or open/)).toBeTruthy();expect(f.calls).not.toContain('unlock');
});
it('keeps admission capabilities out of text and attributes and focuses the new step',async()=>{
 const f=fixture();render(<ReceiverFlow adapters={f.adapters}/>);fireEvent.click(screen.getByText('Create pairing request'));
 await screen.findByText('Save pairing file');
 expect(document.body.innerHTML).not.toContain('joinCapability');expect(document.body.innerHTML).not.toContain('sea-link-v1:');
 expect(document.activeElement?.tagName).toBe('H2');
 expect(screen.getByText(/not independently revocable/)).toBeTruthy();
 fireEvent.click(screen.getByText('Cancel pairing'));
 await waitFor(()=>expect(screen.getByRole('status').textContent).toContain('remains saved'));
});
it('drives both component flows through admission, comparison and durable completion',async()=>{
 const {within}=await import('@testing-library/react');
 const {drawPairingQr}=await import('../dist/qr.js');
 let documentValue='';vi.mocked(drawPairingQr).mockImplementation(async(_,value)=>{documentValue=value;});
 const f=fixture();render(<><ReceiverFlow adapters={f.adapters}/><SenderFlow adapters={f.adapters}/></>);
 const rx=within(screen.getByRole('region',{name:'Add this device'}));
 const tx=within(screen.getByRole('region',{name:'Add another device'}));
 fireEvent.click(rx.getByText('Create pairing request'));await rx.findByText('Save pairing file');
 await waitFor(()=>expect(documentValue).toContain('sea-link-v1:'));
 const file=new File([documentValue],'pairing.json',{type:'application/json'});
 Object.defineProperty(file,'text',{value:async()=>documentValue});
 fireEvent.change(tx.getByLabelText(/Or open/),{target:{files:[file]}});
 fireEvent.click(await tx.findByText('Confirm destination and unlock identity'));
 await tx.findByText('Connect after receiver activation');
 fireEvent.click(rx.getByText('Check source admission and offer'));
 await waitFor(()=>expect(rx.getByRole('alert').textContent).toContain('not ready'));
 fireEvent.click(tx.getByText('Connect after receiver activation'));
 await tx.findByLabelText('Full comparison from the other device');
 fireEvent.click(rx.getByText('Check source admission and offer'));
 await rx.findByLabelText('Full comparison from the other device');
 const comparison=tx.getByLabelText('Full comparison from the other device').closest('fieldset')!.querySelector('code')!.textContent!;
 for(const view of [rx,tx]){
  fireEvent.change(view.getByLabelText('Full comparison from the other device'),{target:{value:comparison}});
  fireEvent.click(view.getByText('Confirm identity, destination and comparison'));
 }
 fireEvent.click(await tx.findByText('Send encrypted identity'));
 await tx.findByText('Check durable acknowledgement');
 expect(tx.getByRole('status').textContent).not.toContain('saved and acknowledged');
 fireEvent.click(rx.getByText('Import using local protection'));
 await waitFor(()=>expect(rx.getByRole('status').textContent).toContain('saved and acknowledged'));
 fireEvent.click(tx.getByText('Check durable acknowledgement'));
 await waitFor(()=>expect(tx.getByRole('status').textContent).toContain('saved and acknowledged'));
});
