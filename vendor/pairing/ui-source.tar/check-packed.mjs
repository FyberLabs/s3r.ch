import {mkdtempSync,writeFileSync,rmSync,copyFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
if(process.env.GITHUB_ACTIONS!=='true')throw Error('CI only');
const root=process.cwd(),scratch=mkdtempSync(join(tmpdir(),'pairing-ui-'));
const run=(cmd,args,cwd=scratch)=>execFileSync(cmd,args,{cwd,stdio:'inherit'});
try{
 writeFileSync(join(scratch,'package.json'),JSON.stringify({private:true,type:'module'}));
 run('npm',['pack','--ignore-scripts','--pack-destination',scratch],root);
 run('npm',['install','--ignore-scripts','--no-audit','--no-fund','--package-lock=false',process.env.SDK_TGZ,process.env.AUTH_TGZ,join(scratch,'sea-device-link-ui-0.0.0.tgz'),'react@19.2.3','react-dom@19.2.3','@types/react@19.2.2','typescript@5.9.3','esbuild@0.25.11']);
 writeFileSync(join(scratch,'consumer.tsx'),`import React from 'react';import {ReceiverFlow,SenderFlow,type Adapters} from 'sea-device-link-ui';import 'sea-device-link-ui/styles.css';declare const adapters:Adapters;export const ui=<><ReceiverFlow adapters={adapters}/><SenderFlow adapters={adapters}/></>;`);
 run(join(scratch,'node_modules/.bin/tsc'),['--noEmit','--strict','--skipLibCheck','--jsx','react-jsx','--module','NodeNext','--moduleResolution','NodeNext','--target','ES2022','consumer.tsx']);
 run(join(scratch,'node_modules/.bin/esbuild'),['consumer.tsx','--bundle','--platform=browser','--format=esm','--outdir=out']);
 // Build the checked-in synthetic harness; execution belongs to nightly owners.
 run(join(scratch,'node_modules/.bin/esbuild'),[resolve(root,'harness/main.tsx'),'--bundle','--platform=browser','--format=esm','--outdir='+resolve(root,'harness-dist')]);
 copyFileSync(join(root,'harness/index.html'),join(root,'harness-dist/index.html'));
}finally{rmSync(scratch,{recursive:true,force:true});}
