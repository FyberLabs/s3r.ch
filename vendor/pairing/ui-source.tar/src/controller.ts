import {Receiver, Sender, LinkError, encodeRequest, decodeRequest, reconcile} from 'sea-device-link';
import type {Scope, Identity, IdentityAdapter, StorageAdapter, Request as LinkRequest} from 'sea-device-link';
import {newCapability, capabilityHash} from 'auth-sea-relay';
import type {Relay} from 'auth-sea-relay';

export type Role = 'sender' | 'receiver';
export type Stage = 'idle'|'invitation'|'destination'|'admitted'|'comparison'|'ready'|'waiting'|'complete'|'cancelled'|'expired';
export type Problem = 'invalid'|'scope'|'expired'|'state'|'comparison'|'crypto'|'identity'|'authority'|'storage'|'transport'|'pending'|'protection'|'unlock'|'camera';
export class PairingProblem extends Error { constructor(readonly code: Problem) { super(code); } }
export interface Adapters {
  scope: Scope;
  authority: IdentityAdapter;
  storage: StorageAdapter;
  /** Returns a NEW relay with role-local authorization. Never forward source tokens. */
  relay(input: {role: Role; request: LinkRequest; capability: string}): Relay;
  /** Fail closed if the destination cannot use its normal local protection. */
  prepareProtection(signal: AbortSignal): Promise<void>;
  /** Caller owns keyring export; returned bytes are consumed and zeroed by this UI. */
  unlock(signal: AbortSignal): Promise<{identity: Identity; keyring: Uint8Array}>;
  now?: () => number;
}
export interface Snapshot {
  stage: Stage; busy: boolean; problem?: Problem;
  scope?: Scope; identity?: Identity; comparison?: string; expiresAt?: number;
}
interface Invitation {v: 1; request: string; receiverHash: string; joinCapability: string}
const LIMIT = 8192;
function parse(text: string): {document: Invitation; request: LinkRequest} {
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > LIMIT) throw new PairingProblem('invalid');
  let o: Invitation;
  try {
    o = JSON.parse(text);
    if (!o || Object.keys(o).sort().join() !== 'joinCapability,receiverHash,request,v' || o.v !== 1 || typeof o.request !== 'string') throw Error();
    for (const value of [o.receiverHash, o.joinCapability]) {
      if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(value)) throw Error();
    }
    return {document: o, request: decodeRequest(o.request)};
  } catch { throw new PairingProblem('invalid'); }
}
export const pairingFileLimit = LIMIT;
/** Presentation orchestration only. All key/protocol decisions remain in the SDK. */
export class PairingController {
  private snapshot: Snapshot = {stage:'idle',busy:false};
  private listeners = new Set<()=>void>();
  private generation = 0;
  private abort = new AbortController();
  private receiver?: Receiver;
  private sender?: Sender;
  private relay?: Relay;
  private invitation?: Invitation;
  private request?: LinkRequest;
  private disposed = false;
  constructor(readonly role: Role, private readonly adapters: Adapters) {}
  getSnapshot = (): Snapshot => this.snapshot;
  subscribe = (fn: ()=>void): (()=>void) => { this.listeners.add(fn); return ()=>this.listeners.delete(fn); };
  private update(patch: Partial<Snapshot>) { this.snapshot = {...this.snapshot,...patch}; for (const fn of this.listeners) fn(); }
  private active(g: number) { return !this.disposed && this.generation === g && !this.abort.signal.aborted; }
  private async run(task: (g: number)=>Promise<void>) {
    if (this.disposed || this.snapshot.busy || this.abort.signal.aborted) return;
    const g = this.generation;
    this.update({busy:true,problem:undefined});
    try { await task(g); }
    catch(e) { if (this.active(g)) this.update({problem: e instanceof LinkError || e instanceof PairingProblem ? e.code : 'transport'}); }
    finally { if (this.active(g)) this.update({busy:false}); }
  }
  private require(stage: Stage) { if (this.snapshot.stage !== stage) throw new PairingProblem('state'); }
  /** Sensitive bootstrap document: canvas/file only, never DOM text or clipboard. */
  pairingDocument(): string | undefined { return this.snapshot.stage === 'invitation' && this.invitation ? JSON.stringify(this.invitation) : undefined; }
  async startReceiver() {
    return this.run(async g => {
      this.require('idle');
      if (this.role !== 'receiver') throw new PairingProblem('state');
      this.receiver?.cancel();
      if (!globalThis.crypto?.subtle) throw new PairingProblem('crypto');
      try { await this.adapters.prepareProtection(this.abort.signal); } catch { throw new PairingProblem('protection'); }
      if (!this.active(g)) return;
      const receiver = await Receiver.create(this.adapters.scope,{now:this.adapters.now});
      if (!this.active(g)) { receiver.cancel(); return; }
      this.receiver = receiver; this.request = receiver.request;
      const capability = newCapability();
      const receiverHash = await capabilityHash(capability);
      if (!this.active(g)) { receiver.cancel(); return; }
      this.relay = this.adapters.relay({role:'receiver',request:this.request,capability});
      this.invitation = {v:1,request:encodeRequest(this.request),receiverHash,joinCapability:newCapability()};
      this.update({stage:'invitation',scope:this.request.scope,expiresAt:this.request.expiresAt});
    });
  }
  async load(document: string) {
    return this.run(async () => {
      this.require('idle');
      if (this.role !== 'sender') throw new PairingProblem('state');
      const parsed = parse(document);
      const scope = this.adapters.scope;
      if ((Object.keys(scope) as (keyof Scope)[]).some(k=>scope[k] !== parsed.request.scope[k])) throw new PairingProblem('scope');
      this.request = parsed.request; this.invitation = parsed.document;
      this.update({stage:'destination',scope:parsed.request.scope,expiresAt:parsed.request.expiresAt});
    });
  }
  async approveDestination() {
    return this.run(async g => {
      this.require('destination');
      if (this.sender) {
        await this.relay!.admit(this.request!,this.invitation!.receiverHash,this.invitation!.joinCapability);
        if (this.active(g)) this.update({stage:'admitted',identity:this.sender.binding.identity});
        return;
      }
      let unlocked;
      try { unlocked = await this.adapters.unlock(this.abort.signal); } catch { throw new PairingProblem('unlock'); }
      try {
        if (!this.active(g)) return;
        const sender = await Sender.create({request:this.request!,expectedScope:this.adapters.scope,...unlocked,authority:this.adapters.authority},{now:this.adapters.now});
        if (!this.active(g)) { sender.cancel(); return; }
        this.sender = sender;
        this.relay ??= this.adapters.relay({role:'sender',request:this.request!,capability:newCapability()});
        await this.relay.admit(this.request!,this.invitation!.receiverHash,this.invitation!.joinCapability);
        if (!this.active(g)) return;
        this.update({stage:'admitted',identity:sender.binding.identity});
      } finally { unlocked.keyring.fill(0); }
    });
  }
  async check() {
    return this.run(async g => {
      if (this.snapshot.stage === 'invitation') {
        await this.relay!.create(this.request!,this.invitation!.joinCapability);
        if (!this.active(g)) return;
        const offer = await this.relay!.offer();
        if (!this.active(g)) return;
        if (!offer) throw new PairingProblem('pending');
        await this.receiver!.bind(offer);
        if (!this.active(g)) return;
        this.invitation = undefined;
        this.update({stage:'comparison',identity:this.receiver!.binding.identity,comparison:this.receiver!.comparison});
      } else if (this.snapshot.stage === 'admitted') {
        await this.relay!.join(this.sender!.offer,this.invitation!.joinCapability);
        if (!this.active(g)) return;
        this.invitation = undefined;
        this.update({stage:'comparison',comparison:this.sender!.comparison});
      } else if (this.snapshot.stage === 'waiting') {
        await this.sender!.finish(this.relay!);
        if (this.active(g)) this.complete();
      } else throw new PairingProblem('state');
    });
  }
  async confirm(peerComparison: string) {
    return this.run(async () => {
      this.require('comparison');
      (this.sender ?? this.receiver)!.confirm(peerComparison);
      this.update({stage:'ready'});
    });
  }
  async transfer() {
    return this.run(async g => {
      this.require('ready');
      if (this.sender) {
        try { await this.sender.send(this.relay!); }
        finally { if (this.active(g) && this.sender.state === 'sent') this.update({stage:'waiting'}); }
      } else {
        await this.receiver!.receive(this.relay!,this.adapters.authority,this.adapters.storage);
        if (this.active(g)) this.complete();
      }
    });
  }
  async retryUpload() {
    return this.run(async () => {this.require('waiting');await this.sender!.send(this.relay!);});
  }
  /** May be used after an uncertain commit or expiry; never imports new keys. */
  async reconcile() {
    return this.run(async g => {
      if (!this.receiver || !['ready','expired'].includes(this.snapshot.stage)) throw new PairingProblem('state');
      if (!await reconcile(this.receiver.binding,this.adapters.storage,this.relay!)) throw new PairingProblem('pending');
      if (this.active(g)) this.complete();
    });
  }
  private complete() { this.invitation=undefined; this.relay?.close(); this.update({stage:'complete',problem:undefined}); }
  expire() {
    if (this.disposed || !this.request || (this.adapters.now ?? Date.now)() < this.request.expiresAt || ['complete','cancelled','expired'].includes(this.snapshot.stage)) return;
    // Sent senders retain only the SDK completion-check key; no further upload.
    if (this.sender?.state === 'sent') return;
    ++this.generation; this.receiver?.cancel(); this.sender?.cancel(); this.invitation=undefined;
    this.update({stage:'expired',busy:false,problem:'expired'});
  }
  async cancel() {
    if (this.snapshot.stage === 'complete') return;
    ++this.generation; this.abort.abort(); this.receiver?.cancel(); this.sender?.cancel(); this.invitation=undefined;
    this.update({stage:'cancelled',busy:false,problem:undefined});
    try { await this.relay?.cancel(); } catch { /* TTL still bounds server state. */ }
    finally { this.relay?.close(); }
  }
  dispose() { this.disposed=true; void this.cancel(); this.listeners.clear(); }
}
