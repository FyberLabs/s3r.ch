import QRCode from 'qrcode';
import {PairingProblem, pairingFileLimit} from './controller.js';
export async function drawPairingQr(canvas: HTMLCanvasElement, document: string) {
  await QRCode.toCanvas(canvas,document,{errorCorrectionLevel:'M',width:320,margin:4});
}
interface Detector { detect(video: HTMLVideoElement): Promise<{rawValue:string}[]> }
type DetectorClass = new(options:{formats:string[]})=>Detector;
/** Camera is requested only by an explicit click. No images leave the device. */
export async function scanPairingQr(video: HTMLVideoElement, signal: AbortSignal): Promise<string> {
  const Detector = (globalThis as typeof globalThis & {BarcodeDetector?: DetectorClass}).BarcodeDetector;
  if (!Detector || !navigator.mediaDevices?.getUserMedia) throw new PairingProblem('camera');
  let stream: MediaStream | undefined;
  const stop=()=>{stream?.getTracks().forEach(track=>track.stop());if(stream&&video.srcObject===stream)video.srcObject=null;};
  signal.addEventListener('abort',stop,{once:true});
  try {
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});
    if(signal.aborted) throw new PairingProblem('camera');
    video.srcObject=stream; await video.play();
    const detector=new Detector({formats:['qr_code']});
    while(!signal.aborted) {
      const result=await detector.detect(video);
      if(signal.aborted) throw new PairingProblem('camera');
      if(result.length) {
        if(new TextEncoder().encode(result[0].rawValue).length>pairingFileLimit) throw new PairingProblem('invalid');
        return result[0].rawValue;
      }
      await new Promise(resolve=>setTimeout(resolve,200));
    }
    throw new PairingProblem('camera');
  } catch(e) { throw e instanceof PairingProblem ? e : new PairingProblem('camera'); }
  finally { stop();signal.removeEventListener('abort',stop); }
}
