'use client';
import React, {useEffect, useId, useRef, useState, useSyncExternalStore} from 'react';
import {PairingController, PairingProblem, pairingFileLimit} from './controller.js';
import type {Adapters, Problem, Role, Snapshot} from './controller.js';
import {drawPairingQr, scanPairingQr} from './qr.js';
export * from './controller.js';
export {drawPairingQr,scanPairingQr} from './qr.js';

const errors: Record<Problem,string> = {
  invalid:'This pairing document is invalid. Ask the receiving device for a new one.',
  scope:'This request belongs to a different application or destination. Start again in the intended application.',
  expired:'The import window expired. Start a new request, or check whether an earlier import was saved.',
  state:'This step is no longer available. Check saved completion or start a new request.',
  comparison:'The comparison did not match. Do not transfer keys. Start again with the intended device.',
  crypto:'Secure cryptography is unavailable or verification failed. Use a supported secure browser; do not bypass verification.',
  identity:'The keyring was refused. Unlock the current complete identity in the source application.',
  authority:'Current identity authorization was refused. Sign in normally and check the identity is still eligible.',
  storage:'Local saving failed or its result is uncertain. Check saved completion before trying another import.',
  transport:'The pairing service could not finish this step. Check connectivity and retry; the previous operation may have succeeded.',
  pending:'The other device is not ready yet. Continue there, then check again here.',
  protection:'Secure local protection is unavailable. Set up supported protection in this application before retrying.',
  unlock:'The source identity could not be unlocked. Unlock it in the source application and retry.',
  camera:'Camera scanning is unavailable or was denied. Use the pairing file instead.',
};
export interface PairingProps {
  adapters: Adapters;
  /** Branding cannot replace comparison, warnings, or confirmation requirements. */
  title?: string;
  className?: string;
  /** Optional additional localized guidance; mandatory security copy stays visible. */
  help?: string;
}
const initial: Snapshot={stage:'idle',busy:false};
const idleSubscribe=()=>()=>{};
const idleSnapshot=()=>initial;
/** Adapter identity is fixed for a mount. Remount with a new key on account/scope change. */
export function usePairing(role: Role, adapters: Adapters) {
  const first=useRef(adapters);
  const [controller,setController]=useState<PairingController>();
  useEffect(()=>{
    const value=new PairingController(role,first.current);setController(value);
    return ()=>value.dispose();
  },[role]);
  const snapshot=useSyncExternalStore(controller?.subscribe??idleSubscribe,controller?.getSnapshot??idleSnapshot,idleSnapshot);
  useEffect(()=>{if(!controller)return;const timer=setInterval(()=>controller.expire(),1000);return ()=>clearInterval(timer);},[controller]);
  return {controller,snapshot};
}
function Qr({controller}:{controller:PairingController}) {
  const canvas=useRef<HTMLCanvasElement>(null);const [failed,setFailed]=useState(false);
  useEffect(()=>{
    let active=true;const node=canvas.current;const document=controller.pairingDocument();
    if(node&&document) void drawPairingQr(node,document).catch(()=>{if(active)setFailed(true);});
    return ()=>{active=false;if(node)node.getContext('2d')?.clearRect(0,0,node.width,node.height);};
  },[controller]);
  return <>{failed?<p role="status">QR display is unavailable. Use the pairing file.</p>:<canvas ref={canvas} role="img" aria-label="Pairing QR for the source device"/>}</>;
}
function Download({controller}:{controller:PairingController}) {
  const [failed,setFailed]=useState(false);
  function download() {
    const document=controller.pairingDocument();if(!document)return;
    try {
      const url=URL.createObjectURL(new Blob([document],{type:'application/json'}));
      const a=window.document.createElement('a');a.href=url;a.download='device-pairing.json';a.click();
      setTimeout(()=>URL.revokeObjectURL(url),1000);
    } catch {setFailed(true);}
  }
  return <><button type="button" onClick={download}>Save pairing file</button>{failed&&<p role="alert">The pairing file could not be saved. Try the QR path or a supported browser.</p>}</>;
}
function Input({controller}:{controller:PairingController}) {
  const video=useRef<HTMLVideoElement>(null);const scan=useRef<AbortController | undefined>(undefined);
  const [scanning,setScanning]=useState(false);const [problem,setProblem]=useState<Problem>();
  useEffect(()=>()=>scan.current?.abort(),[]);
  async function camera(){
    scan.current?.abort();const abort=new AbortController();scan.current=abort;setScanning(true);setProblem(undefined);
    try {const text=await scanPairingQr(video.current!,abort.signal);if(!abort.signal.aborted)await controller.load(text);}
    catch(e){if(!abort.signal.aborted)setProblem(e instanceof PairingProblem?e.code:'camera');}
    finally{if(!abort.signal.aborted)setScanning(false);}
  }
  async function file(event:React.ChangeEvent<HTMLInputElement>){
    const file=event.target.files?.[0];event.target.value='';if(!file)return;
    scan.current?.abort();setScanning(false);setProblem(undefined);
    if(file.size>pairingFileLimit){setProblem('invalid');return;}
    try {await controller.load(await file.text());}catch{setProblem('invalid');}
  }
  return <div><button type="button" onClick={()=>void camera()} disabled={scanning}>Scan receiving device QR</button>
    {scanning&&<button type="button" onClick={()=>{scan.current?.abort();setScanning(false);}}>Stop camera</button>}
    <video ref={video} muted playsInline hidden={!scanning} aria-label="Pairing camera preview"/>
    <label>Or open the receiving device’s pairing file<input type="file" accept="application/json,.json" onChange={event=>void file(event)} /></label>
    {problem&&<p role="alert">{errors[problem]}</p>}
  </div>;
}
function Flow({role,adapters,title,className,help}:PairingProps&{role:Role}) {
  const {controller,snapshot:s}=usePairing(role,adapters);const id=useId();const heading=useRef<HTMLHeadingElement>(null);
  const [comparison,setComparison]=useState('');
  useEffect(()=>{heading.current?.focus();},[s.stage]);
  const terminal=['complete','cancelled','expired'].includes(s.stage);
  return <section className={`sea-device-link ${className??''}`} aria-labelledby={id} aria-busy={s.busy}>
    <h2 id={id} ref={heading} tabIndex={-1}>{title??(role==='receiver'?'Add this device':'Add another device')}</h2>
    <p>Copies of this identity are not independently revocable. This does not copy application sessions, roles or permissions.</p>
    {help&&<p>{help}</p>}
    <p role="status" aria-live="polite">{s.busy?'Working…':s.stage==='complete'?'Identity saved and acknowledged.':s.stage==='waiting'?'Waiting for durable acknowledgement from the receiving device.':s.stage==='admitted'?'Request admitted. Continue on the receiving device, then check here.':s.stage==='cancelled'?'Pairing stopped. Any identity already saved remains saved.':s.stage==='expired'?'Pairing expired.':`Step: ${s.stage}`}</p>
    {s.problem&&<p role="alert">{errors[s.problem]}</p>}
    {s.scope&&<dl><dt>Source</dt><dd>{s.scope.sourceOrigin}</dd><dt>Destination</dt><dd>{s.scope.destinationOrigin}</dd><dt>Application</dt><dd>{s.scope.application}</dd><dt>Tenant</dt><dd>{s.scope.tenant}</dd><dt>Audience</dt><dd>{s.scope.audience}</dd></dl>}
    {s.identity&&<p>Identity: <code>{s.identity.principal}</code></p>}
    {s.expiresAt&&<p>Import deadline: <time>{new Date(s.expiresAt).toLocaleTimeString()}</time></p>}
    <fieldset disabled={s.busy||!controller}>
    {controller&&s.stage==='idle'&&(role==='receiver'?<button type="button" onClick={()=>void controller.startReceiver()}>Create pairing request</button>:<Input controller={controller}/>)}
    {controller&&s.stage==='invitation'&&<><p>On the source device, scan this QR or open the pairing file. It contains a short-lived admission capability. Share only with your intended source device and delete the file after pairing. Never paste it into chat or a clipboard manager.</p><Qr controller={controller}/><Download controller={controller}/><button type="button" onClick={()=>void controller.check()}>Check source admission and offer</button></>}
    {s.stage==='destination'&&<button type="button" onClick={()=>void controller?.approveDestination()}>Confirm destination and unlock identity</button>}
    {s.stage==='admitted'&&<button type="button" onClick={()=>void controller?.check()}>Connect after receiver activation</button>}
    {s.stage==='comparison'&&<><p>Verify the identity and destination above. Compare every group directly with the other device, using a trusted independent channel. Do not obtain this value from the relay.</p><p><code>{s.comparison}</code></p><label>Full comparison from the other device<input autoComplete="off" spellCheck={false} value={comparison} onChange={event=>setComparison(event.target.value)} /></label><button type="button" onClick={()=>{void controller?.confirm(comparison);setComparison('');}}>Confirm identity, destination and comparison</button></>}
    {s.stage==='ready'&&<button type="button" onClick={()=>void controller?.transfer()}>{role==='sender'?'Send encrypted identity':'Import using local protection'}</button>}
    {s.stage==='waiting'&&<><button type="button" onClick={()=>void controller?.check()}>Check durable acknowledgement</button><button type="button" onClick={()=>void controller?.retryUpload()}>Retry identical upload</button></>}
    {role==='receiver'&&['ready','expired'].includes(s.stage)&&<button type="button" onClick={()=>void controller?.reconcile()}>Check saved completion</button>}
    </fieldset>
    {!terminal&&(s.stage!=='idle'||s.busy)&&<button type="button" onClick={()=>void controller?.cancel()}>Cancel pairing</button>}
  </section>;
}
function Restartable(props:PairingProps&{role:Role}) {
  const [generation,setGeneration]=useState(0);
  return <><Flow key={generation} {...props}/><button type="button" onClick={()=>setGeneration(n=>n+1)}>Start a new pairing request</button></>;
}
export function SenderFlow(props:PairingProps){return <Restartable {...props} role="sender"/>;}
export function ReceiverFlow(props:PairingProps){return <Restartable {...props} role="receiver"/>;}
