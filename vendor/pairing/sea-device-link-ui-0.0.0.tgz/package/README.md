# SEA device pairing UI

Independent React 18/19 package for SDK `sea-device-link` and Auth's
`auth-sea-relay`. Import `SenderFlow`, `ReceiverFlow`, `usePairing`, or the
framework-independent `PairingController`. Import `sea-device-link-ui/styles.css`
for mobile layout and visible keyboard focus. No Next.js runtime, environment
variables, route aliases, telemetry, or persistence is included.

Supply trusted `Adapters`: exact expected scope, current ACL authority, SociACL
complete-keyring export through `unlock`, destination atomic protected storage,
local protection readiness, and a role-specific relay factory. The relay factory
wraps Auth's `createRelay` with configured HTTPS transport. Only the source adds
its own person bearer; receiver calls never forward it. Preserve Auth's header,
Origin, size, scope and redirect restrictions. See Auth #62 and ACL #171.

Each adapter set is fixed for a component mount. **Remount with a new React key
on logout, account, tenant, scope or authorization-context change.** Consumers
must cancel in-flight work and refuse stale account writes in their storage
adapter. `unlock` returns a fresh byte buffer owned by this package; it is zeroed
even on cancellation/refusal. Never return a shared live keyring buffer. Private
material stays inside SDK calls and owner adapters, never component snapshots,
rendered text, error strings, analytics or clipboard helpers.

## Sequence and deliberate sharing

Receiver checks local protection, creates the SDK request locally and generates
its receiver capability. QR canvas and the camera-free JSON file carry the SAME
versioned document: the SDK `encodeRequest` representation, receiver capability
hash, and a narrow random join capability. The join capability is sensitive
bootstrap material: share only with the intended source, never clipboard/chat or
generic form persistence, and delete the file afterward. The receiver capability,
SEA private keys, OAuth tokens and recovery material never enter this document.
The package provides no clipboard helper and never renders document bytes as text,
attributes, image URLs or a hidden input. QR is drawn locally to canvas. Files are
created only after an explicit save click; temporary object URLs are revoked.
Only public scope, identity and independent comparison data appear in text.

The source scans or opens the file, confirms the destination and unlocks. It
uses the SDK to validate and bind the identity, then Auth `admit` reserves the
exact request and capability hashes. The receiver checks to activate `create`;
the source then `join`s, and the receiver fetches/binds its offer. Explicit check
buttons avoid background polling and let owners apply Auth's rate limits.

Both users must enter the full comparison from the OTHER device through an
independent trusted channel. There is no auto-confirm or boolean-only bypass.
Only then can the source send and the receiver import. SDK validation owns
cryptography, current authority and the destination write guard. Sender success
requires SDK `finish`; receiver success requires durable storage and successful
acknowledgement. Copying a key never grants new permissions or independent device
revocation. Mandatory security copy cannot be overridden; title, extra guidance,
CSS and wrapper layout can be branded.

An uncertain upload can retry the SDK's identical upload. An uncertain receiver
commit can check saved completion with SDK `reconcile`, including after expiry;
this never imports new keys. Cancellation/unmount abort SDK work, clear bootstrap
references and best-effort cancel/close the relay. Cancellation cannot undo a
commit that already happened. Restart uses a new SDK session. Complete restart
recovery across page reload belongs to consumer-protected storage: persist the
SDK binding, matching completion and receiver capability through owner adapters,
then call the SDK's standalone `reconcile`. This component stores none of them.

## Accessibility and capability failures

Stage headings receive focus, status changes are announced, errors are sanitized
and actionable, all controls have labels, and touch targets are at least 44px.
Camera access occurs only after a click; tracks stop on cancellation, success or
unmount. Native BarcodeDetector absence or camera denial offers the file path.
QR encoding failure also leaves the file path available. Missing secure crypto,
protection, authority or storage never triggers a weaker import. Components must
be served in a secure context. Owner adapters must honor abort signals and the
SDK atomic storage contract even after the UI is removed.

## Validation and handoff

The dedicated private CI lane builds pinned merged SDK/Auth packages, runs
component units and deterministic SDK contracts, then checks package exports,
declarations, CSS and browser bundling from a packed consumer. All checks run in
CI. `harness/main.tsx` and `harness/index.html` build into `harness-dist` for the
nightly owner; the harness uses synthetic keys, a memory relay and nonpersistent
storage and has no real services. It is never a product login qualification.
Do not run browser scenarios manually or in this PR lane. Infra #1559 owns
fixture setup, readiness, teardown and registered nightly execution. Portal #131
and s3r.ch #519 own real routes, authentication and protection/storage adapters.

Closes component slice controlplane-portal #130 under spanopticon #85; it does not
complete those consumers or plane configuration #141.
