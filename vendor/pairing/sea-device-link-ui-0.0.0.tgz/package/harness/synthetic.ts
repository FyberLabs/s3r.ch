import {newCapability} from 'auth-sea-relay';
import type {Adapters} from '../dist/controller.js';
import type {Binding, Completion, Envelope, Offer} from 'sea-device-link';
export function fixture(start=1700000000000) {
  let clock=start;
  const scope={sourceOrigin:'https://source.example',destinationOrigin:'https://destination.example',application:'unit',tenant:'tenant',audience:'test'};
  const point=newCapability()+'.'+newCapability();
  const identity={principal:point,pub:point,epub:point,rotationSeq:0};
  const keyring=new Uint8Array([11,22,33,44]);
  let saved: {binding:Binding; completion:Completion; bytes:Uint8Array}|undefined;
  let admitted=false,activated=false,offer:Offer|undefined,envelope:Envelope|undefined,completion:Completion|undefined;
  const calls:string[]=[];
  const failures=new Set<string>();
  const fail=(name:string)=>{calls.push(name);if(failures.has(name))throw Error('PRIVATE-SENTINEL');};
  const adapters:Adapters={scope,now:()=>clock,
    async prepareProtection(){fail('protection');},
    async unlock(){fail('unlock');return {identity,keyring:keyring.slice()};},
    authority:{async validateKeyring(){fail('identity');},async current(b){fail('authority');return {revision:'fixed',validUntil:b.expiresAt};}},
    storage:{async lookup(){fail('lookup');return saved?.completion??null;},async commit(input){fail('storage');await input.beforeCommit();if(input.signal.aborted)throw Error();saved={binding:input.binding,completion:input.completion,bytes:input.keyring.slice()};}},
    relay:()=>({
      async admit(){fail('admit');admitted=true;},async create(){fail('create');if(!admitted)throw Error();activated=true;},
      async join(value){fail('join');if(!activated)throw Error();offer=value;},async offer(){fail('offer');return offer??null;},
      async send(_,value){fail('send');envelope=value;},async receive(){fail('receive');return envelope??null;},
      async complete(_,value){completion=value;fail('complete');},async completed(){fail('completed');return completion??null;},
      async cancel(){calls.push('cancel');envelope=undefined;},close(){calls.push('close');},
    }),
  };
  return {adapters,calls,failures,get saved(){return saved;},advance(ms:number){clock+=ms;}};
}
