import React from 'react';
import {createRoot} from 'react-dom/client';
import {ReceiverFlow,SenderFlow} from '../dist/index.js';
import '../dist/styles.css';
import {fixture} from './synthetic.js';
const f=fixture(Date.now());
createRoot(document.getElementById('root')!).render(<main>
 <h1>Synthetic pairing component harness</h1>
 <p>Unit adapters only. No real identity, account, service, or persistent storage. Use a real consumer for product qualification.</p>
 <ReceiverFlow adapters={f.adapters}/><SenderFlow adapters={f.adapters}/>
</main>);
